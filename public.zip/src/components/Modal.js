import React, { useState } from 'react'
import '../css/modal.css'
import { FaTimes } from "react-icons/fa";
import { USERS } from '../userData';
export const Modal = ({ closeModal, searchByValue, setUserData }) => {

    const [searchValue, setSearchValue] = useState("");

    const closeBtnHandler = () => {
        closeModal();
    }

    const submitHandler = (evt) => {
        evt.preventDefault();
        if (!searchValue) return;
        const userData = getUserData()
        setUserData(userData);
    }

    const getUserData = () => {
        const updatedUser = USERS.filter(item => {
            if (searchByValue === 'name') {
                return item.name === searchValue;
            } else if (searchByValue === 'phone') {
                return item.mobile === +searchValue;
            }
        })
        return updatedUser;
    }

    return (
        <div className="modal-container">
            <div className="close-btn-container">
                <button className="close-btn" onClick={closeBtnHandler}><FaTimes /></button>
            </div>

            <form onSubmit={submitHandler}>
                <input
                    type={`${searchByValue === 'name' ? 'text' : 'number'}`}
                    name="searchTxt"
                    id="searchTxt"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                    placeholder={`${searchByValue === 'name' ? 'Enter the user name' : 'Enter contact number'}`} />

                <div className="btn-container">
                    <button className="btn-submit" type='submit'>Submit</button>
                    <button className="btn-cancel" type="button" onClick={() => closeModal()}>Cancel</button>
                </div>

            </form>


        </div>
    )
}
