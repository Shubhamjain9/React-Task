
import React, { useState } from 'react'
import { Modal } from './Modal';


export const Users = () => {

    const [searchByValue, setSearchByValue] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [userData, setUserData] = useState([]);

    const onSearchByChange = (evt) => {
        const searchByValue = evt.target.value;
        setSearchByValue(searchByValue)
        setIsModalOpen(true);
        setUserData([]);
    }

    const closeModal = () => {
        setIsModalOpen(false);
    }

    return (
        <>
            <div className="container">
                <label htmlFor="search by">Search By</label>
                <select value={searchByValue} onChange={onSearchByChange} >
                    <option>Select</option>
                    <option value={`name`}>Name</option>
                    <option value={`phone`}>Phone</option>
                </select>
            </div>

            {isModalOpen && <Modal closeModal={closeModal}
                searchByValue={searchByValue} setUserData={setUserData} />}

            {userData.length > 0 &&
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                    </tr>
                    {userData.map((user, i) => {
                        return <tr key={i}>
                            <td>{user.name}</td>
                            <td>{user.mobile}</td>
                        </tr>
                    })}
                </table>}
        </>

    )
}
