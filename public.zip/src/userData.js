export const USERS = [
    { name: 'Shubham', mobile: 976348632 },
    { name: 'sanjiv', mobile: 9733282323 },
    { name: 'Shivam', mobile: 6465554567 },
    { name: 'Agam', mobile: 9765435890 },
    { name: 'Prateek', mobile: 2125551234 },
]